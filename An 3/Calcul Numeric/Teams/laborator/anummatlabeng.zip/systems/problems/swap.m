function [xs,ys]=swap(x,y)
t=x; xs=y; ys=t;