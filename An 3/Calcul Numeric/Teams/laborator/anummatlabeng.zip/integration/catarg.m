%catarg
clf
plot([0,0],[0,8],'k-','LineWidth',4)
hold on
plot([0,-3],[0,0],'k--')
plot([0,-3],[8,0],'k-')
plot([4,4],[0,8],'k-')
plot([0,0],[-1,0],'k-')
text(4.2,4,'L','FontSize',14)
text(0.5,0.5,'A','FontSize',14)
text(-0.5,8,'B','FontSize',14)
text(-2.5,3,'T','FontSize',14)
text(-3.5,0,'O','FontSize',14)

