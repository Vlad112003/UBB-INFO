y=15;
x=cosh(y);
-log(x-sqrt(x^2-1))
log(x+x*sqrt(1-(1/x)^2))
