%P3_5
x=rand(1,n)*realmin;
sum(x.*(1./x)==1)