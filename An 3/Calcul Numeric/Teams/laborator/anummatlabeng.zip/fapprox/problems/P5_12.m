%P5_12
T=[94,205,371];
ro=[929,902,860];
syms x y
y=lagr(T,ro,x);
pretty(y)
y251=lagr(T,ro,251)