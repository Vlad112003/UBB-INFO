x = -2:2/25:2;
plot(x,cosh(x),'-ro',x,sinh(x),'-.b')
h = legend('cosh','sinh',4); 