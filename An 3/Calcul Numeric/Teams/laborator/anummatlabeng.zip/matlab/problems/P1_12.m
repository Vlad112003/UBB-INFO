%P1_12
x=[-30,-3,3,30];
expss(x)
[abs(expss(x)-exp(x))]./exp(x)