t=0:pi/50:2*pi;
a=2;
r=a*(1+cos(t));
polar(t,r)
title('cardioid')
