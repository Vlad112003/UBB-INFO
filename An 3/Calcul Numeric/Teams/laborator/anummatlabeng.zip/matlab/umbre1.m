subplot(1,3,1)
sphere(16)
axis square
shading flat
title('shading flat')
subplot(1,3,2)
sphere(16)
axis square
shading faceted
title('shading faceted')
subplot(1,3,3)
sphere(16)
axis square
shading interp
title('shading interp')
