function Z=pahyp
[X,Y]=meshgrid(linspace(-1,1,30));
Z=X.^2-Y.^2;
