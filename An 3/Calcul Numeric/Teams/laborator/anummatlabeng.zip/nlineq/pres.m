function y=pres(r,k)
y=k(1)*exp(k(2)*r)+k(3)*r-500;