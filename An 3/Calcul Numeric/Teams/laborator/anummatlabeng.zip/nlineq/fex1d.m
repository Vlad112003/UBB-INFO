function y=fex1d(x)
y=[2*x(1), 2*x(2); 3*x(1)^2, -1];