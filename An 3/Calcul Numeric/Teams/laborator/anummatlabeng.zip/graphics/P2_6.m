%P2_6
subplot(1,2,1)
elicoid(2,1,1,1,0)
subplot(1,2,2)
elicoid(3,1,2,10,1)