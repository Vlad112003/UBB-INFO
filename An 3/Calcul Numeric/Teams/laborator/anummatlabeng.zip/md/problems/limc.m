function z=limc(x)
z=zeros(size(x));