function z=limd(x)
z=x;