function Z=futest(X,Y)
Z = X .* exp(-X.^2 - Y.^2);
