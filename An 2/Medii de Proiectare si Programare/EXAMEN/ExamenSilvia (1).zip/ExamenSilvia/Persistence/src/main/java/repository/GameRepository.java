package repository;

import model.Game;

public interface GameRepository extends Repository<Game, Integer> {
}
