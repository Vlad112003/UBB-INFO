package repository;


import model.Configuration;

public interface ConfigurationRepository extends Repository<Configuration,Integer> {
}
