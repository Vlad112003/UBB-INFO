package network;

public enum ResponseType {
    OK, ERROR, ENDGAME
}
