package network;

public enum RequestType {
    LOGIN, LOGOUT, GETCONF, PLAY
}
