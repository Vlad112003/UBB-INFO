package model;

public interface Entity<Tid> {
    Tid getId();
    void setId(Tid id);
}
