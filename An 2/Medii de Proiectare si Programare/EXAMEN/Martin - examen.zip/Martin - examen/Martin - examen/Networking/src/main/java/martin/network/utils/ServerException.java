package martin.network.utils;


public class ServerException extends Exception{
    public ServerException(String message, Throwable cause) {
        super(message, cause);    
    }
}
