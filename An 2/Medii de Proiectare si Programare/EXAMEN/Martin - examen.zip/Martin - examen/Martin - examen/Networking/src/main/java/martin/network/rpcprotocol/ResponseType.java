package martin.network.rpcprotocol;


public enum ResponseType {
    OK,
    ERROR,
    RANKING,
    CONTROL;
}

