package martin.network.rpcprotocol;


public enum RequestType {
    LOGIN,
    LOGOUT,
    GET_RANKING,
    GUESS,
    SET_CONTROL_GAME_OVER;
}
