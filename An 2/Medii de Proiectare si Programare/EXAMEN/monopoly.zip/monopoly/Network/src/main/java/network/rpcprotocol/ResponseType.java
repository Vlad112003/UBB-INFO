package network.rpcprotocol;

public enum ResponseType {
    ERROR, GAME_FINISHED, OK
}
