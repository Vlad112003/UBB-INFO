package services;

import java.util.Collection;

public interface IObserver {
    //void gameFinished(Collection<Game> games) throws Exception;
}
